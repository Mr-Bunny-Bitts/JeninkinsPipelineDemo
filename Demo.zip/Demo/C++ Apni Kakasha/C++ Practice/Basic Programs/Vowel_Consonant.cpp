#include<iostream>
/*
int main()
{
    char vc;
    std::cout << "Enter a character:";
    std::cin >> vc;
    if(vc=='a' || vc=='e' || vc=='i' || vc=='o' || vc=='u' || vc=='A' || vc=='E' || vc=='I' || vc=='O' || vc=='U')
        std::cout << "It's a VOWEL";
    else
        std::cout << "It's a CONSONANT";

    return 0;
}
*/
int main()
{
    char vc;
    std::cout << "Enter a Character:";
    std::cin >> vc;
    int IsUpper, IsLower;

    IsLower = (vc=='a' || vc=='e' || vc=='i' || vc=='o' || vc=='u');
    IsUpper = (vc=='A' || vc=='E' || vc=='I' || vc=='O' || vc=='U');

    if(IsUpper || IsLower)
        std::cout << vc << " is VOWEL";
    else
        std::cout << vc << " is CONSONANT";

    return 0;

}