#include<iostream>

int main()
{
    int a;
    std::cout << "Enter a number:";
    std::cin >> a;
    if(a%2==0)
        std::cout << "Even Number.";
    else
        std::cout << "Odd Number";

    return 0;
}