#include<iostream>

int main()
{
    int sideA, sideB, sideC;
    std::cout << "Enter the sides of traingle.\n";
    std::cout << "Side A:\n" ;
    std::cin >> sideA;
    std::cout << "Side B:\n" ;
    std::cin >> sideB;
    std::cout << "Side C:\n" ;
    std::cin >> sideC;    

    if((sideA==sideB) && (sideB==sideC))
    {
        std::cout << "Equilateral Traingle";
    }  
    else if ((sideA==sideB) || (sideA==sideC) || (sideB==sideC))
    {
        std::cout << "Isosceles Traingle";
    }
    else
    {
        std::cout << "Scalene Traingle";
    }

    return 0;
}