#include<iostream>
/*
int main()
{
    int a, b;
    std::cout << "Enter two values:";
    std::cin >> a >> b;
    if(a>b)
        std::cout << a << " is Greater than " << b;
    else if(a==b)
        std::cout << a << " is equal to " << b;
    else
        std::cout << a << " is less than " << b;

    return 0;
}

*/
int main()
{
    int n1, n2;
    std::cout << "Enter Numbers:";
    std::cin >> n1 >> n2;
    int max, min;
    if(n1>n2)
    {
        max = n1;
        min = n2;
    }
    else
    {
        max = n2;
        min = n1;
    }

    std::cout << "Maximum is :" << max << "\n";
    std::cout << "Minimum is :" << min << "\n";

    return 0;
}